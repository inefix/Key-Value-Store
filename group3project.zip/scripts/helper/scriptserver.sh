echo "lauching server"
cd ../..
./server

sleep 15
